"""
Middleware package for the Deadpool API.
Contains middleware components for logging, error handling, etc.
"""